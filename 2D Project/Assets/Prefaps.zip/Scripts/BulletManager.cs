﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletManager : Singleton<BulletManager> {

    public GameObject bulletPrefap;
    public Transform playerTr;
    public float minSpeed = 5.0f;
    public float maxSpeed = 5.0f;

    public float generateSpeed = 0.1f;
    List<GameObject> bulletPool;
    List<GameObject> slimePool;
    List<GameObject> fastBulletPool;
    List<GameObject> seekerBulletPool;


	// Use this for initialization
	void Start () {
        bulletPool = new List<GameObject>();
        slimePool = new List<GameObject>();
        fastBulletPool = new List<GameObject>();
        seekerBulletPool = new List<GameObject>();

        for (int i = 0; i < 2000; i++)
        {
            GameObject bulletObj = Instantiate(bulletPrefap, gameObject.transform);
            bulletObj.SetActive(false);
            bulletPool.Add(bulletObj);
        }

        for (int i = 0; i < 200; i++)
        {
            GameObject slimeObj = Instantiate(bulletPrefap, gameObject.transform);
            slimeObj.SetActive(false);
            slimePool.Add(slimeObj);

            GameObject fastbulletObj = Instantiate(bulletPrefap, gameObject.transform);
            fastbulletObj.SetActive(false);
            slimePool.Add(fastbulletObj);

            GameObject seekerBulletObj = Instantiate(bulletPrefap, gameObject.transform);
            seekerBulletObj.SetActive(false);
            slimePool.Add(seekerBulletObj);
        }

        StartCoroutine(GenerateBullet());
	}
	
    IEnumerator GenerateBullet()
    {
        while(true)
        {
            foreach(GameObject bullet in bulletPool)
            {
                if(!bullet.activeSelf)
                {
                    bullet.SetActive(true);

                    float xPos = 0.0f, yPos = 0.0f;

                    while (Mathf.Abs(xPos) < 10.0f) 
                    {
                        xPos = Random.Range(-20.0f, 20.0f);   
                    }
                    while (Mathf.Abs(yPos) < 10.0f) 
                    {
                        yPos = Random.Range(-20, 20);
                    }

                    bullet.transform.position = new Vector3(xPos, yPos, 0);

                    bullet.GetComponent<BulletCtrl>().moveDir = new Vector3(playerTr.position.x + Random.Range(-2, 2) - bullet.transform.position.x, playerTr.position.y + Random.Range(-2, 2) - bullet.transform.position.y).normalized;
                    bullet.GetComponent<BulletCtrl>().speed = Random.Range(minSpeed, maxSpeed);

                    yield return new WaitForSeconds(generateSpeed);
                }
            }
        }
    }

    IEnumerator GenerateFastBullet()
    {
        while (true)
        {
            foreach (GameObject bullet in fastBulletPool)
            {
                if (!bullet.activeSelf)
                {
                    bullet.SetActive(true);

                    float xPos = 0.0f, yPos = 0.0f;

                    while (Mathf.Abs(xPos) < 10.0f)
                    {
                        xPos = Random.Range(-20.0f, 20.0f);
                    }
                    while (Mathf.Abs(yPos) < 10.0f)
                    {
                        yPos = Random.Range(-20, 20);
                    }

                    bullet.transform.position = new Vector3(xPos, yPos, 0);

                    bullet.GetComponent<BulletCtrl>().moveDir = new Vector3(playerTr.position.x + Random.Range(-2, 2) - bullet.transform.position.x, playerTr.position.y + Random.Range(-2, 2) - bullet.transform.position.y).normalized;
                    bullet.GetComponent<BulletCtrl>().speed = Random.Range(minSpeed, maxSpeed);

                    yield return new WaitForSeconds(generateSpeed);
                }
            }
        }
    }

    IEnumerator GenerateSeekerBullet()
    {
        while (true)
        {
            foreach (GameObject bullet in seekerBulletPool)
            {
                if (!bullet.activeSelf)
                {
                    bullet.SetActive(true);

                    float xPos = 0.0f, yPos = 0.0f;

                    while (Mathf.Abs(xPos) < 10.0f)
                    {
                        xPos = Random.Range(-20.0f, 20.0f);
                    }
                    while (Mathf.Abs(yPos) < 10.0f)
                    {
                        yPos = Random.Range(-20, 20);
                    }

                    bullet.transform.position = new Vector3(xPos, yPos, 0);

                    bullet.GetComponent<BulletCtrl>().moveDir = new Vector3(playerTr.position.x + Random.Range(-2, 2) - bullet.transform.position.x, playerTr.position.y + Random.Range(-2, 2) - bullet.transform.position.y).normalized;
                    bullet.GetComponent<BulletCtrl>().speed = Random.Range(minSpeed, maxSpeed);

                    yield return new WaitForSeconds(generateSpeed);
                }
            }
        }
    }

    public void Restart()
    {
        foreach (GameObject bullet in bulletPool)
        {
            bullet.SetActive(false);
        }
    }
}
